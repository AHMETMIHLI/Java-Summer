package day02_variables;

public class C01_Variables {

    public static void main(String[] args) {

              int             not            =                60                    ;
        // data türü     variable ismi     assigment sign   variable degeri     işlem bitti işareti

            int not2   =   70 ;
        // variable     deger
        // Java once degeri hesaplar sonra assign işlemini yapar.

        // not2'yi 80 yapalım

        not2=90;

        // yeni bir int variable oluşturalım ilk iki variable'in ortalaması olsun

        int ort =(not+not2)/2;

        System.out.println(ort);

        // " " içinde yazılan herşey metindir, Java "" içinde ne görürse o şekilde yazdırır.
        // eğer bir variable'ın değerini yazdırmak istiyorsanız "" olmadan variable ismini yazmalısınız


    }
}
