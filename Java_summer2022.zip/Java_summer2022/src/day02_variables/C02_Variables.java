package day02_variables;

public class C02_Variables {

    public static void main(String[] args) {

        int sayi=10;
        boolean guzelMi=true;
        char sayim='3';

        System.out.println(sayi);//10
        System.out.println("sayi");// sayi
        System.out.println("sayi : " + sayi); // sayi:10
        System.out.println(guzelMi);
        System.out.println(sayim);

    }
}
