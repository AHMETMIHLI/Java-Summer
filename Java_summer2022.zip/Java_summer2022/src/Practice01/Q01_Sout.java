package Practice01;

public class Q01_Sout {
    public static void main(String[] args) {

         /*
  Konsolda asagidaki ciktiyi yazdiriniz
        T
        E
        C
        H
        P
        R
        O
        E
        D
        U
        C
        A
        T
        I
        O
        N
         */

        System.out.println("T");
        System.out.println("E");
        System.out.println("C");
        System.out.println("H");
        System.out.println("P");
        System.out.println("R");
        System.out.println("O");
        System.out.println(" ");
        System.out.println("E");
        System.out.println("D");
        System.out.println("U");
        System.out.println("C");
        System.out.println("A");
        System.out.println("T");
        System.out.println("I");
        System.out.println("O");
        System.out.println("N");
    }

}
