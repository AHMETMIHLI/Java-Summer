package Practice01;

public class Q05_EscapeSequences {
}
