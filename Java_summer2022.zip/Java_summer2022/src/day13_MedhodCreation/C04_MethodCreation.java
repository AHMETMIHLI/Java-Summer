package day13_MedhodCreation;

public class C04_MethodCreation {
    public static void main(String[] args) {

        // input olarak verilen iki integer'i toplayıp yazdıran bir method olusturun

        int input1=10;
        int input2=20;

        sayilarınToplamı(input1,input2);
    }

    public static void sayilarınToplamı(int input1, int input2) {
        int toplam= input1+input2;
        System.out.println(toplam);
    }
}
