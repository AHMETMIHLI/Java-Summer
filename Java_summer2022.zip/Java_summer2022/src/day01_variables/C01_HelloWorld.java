package day01_variables;

public class C01_HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello World , Hello Java");
    }
}
